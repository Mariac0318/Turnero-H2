
package ProgramaTurnos;

import javax.persistence.Entity;
import javax.persistence.Table;

/**
 *
 * @author camil
 */

@Entity
@Table (name = "PuestoAtención")
public class PuestoAtención {
    
    
    private int Hora;
    private String Fecha;

    public PuestoAtención(int Hora, String Fecha) {
        this.Hora = Hora;
        this.Fecha = Fecha;
    }

    public int getHora() {
        return Hora;
    }

    public void setHora(int Hora) {
        this.Hora = Hora;
    }

    public String getFecha() {
        return Fecha;
    }

    public void setFecha(String Fecha) {
        this.Fecha = Fecha;
    }
    
}
