
package ProgramaTurnos;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

/**
 *
 * @author camil
 */

@Entity
@Table (name = "Persona")
public class Cliente extends Persona {
    
    @Id
    private int identificacion;
    @Column
    private String Nombre;
    @Column
    private String Apellido;
    @Column
    private int Telefono;

    public Cliente() {
    }

    public Cliente(String Nombre, String Apellido, int Telefono) {
        super(Nombre, Apellido, Telefono);
    }

    public int getIdentificacion() {
        return identificacion;
    }

    public void setIdentificacion(int identificacion) {
        this.identificacion = identificacion;
    }

    public String getNombre() {
        return Nombre;
    }

    public void setNombre(String Nombre) {
        this.Nombre = Nombre;
    }

    public String getApellido() {
        return Apellido;
    }

    public void setApellido(String Apellido) {
        this.Apellido = Apellido;
    }

    public int getTelefono() {
        return Telefono;
    }

    public void setTelefono(int Telefono) {
        this.Telefono = Telefono;
    }
    
    
    
}
