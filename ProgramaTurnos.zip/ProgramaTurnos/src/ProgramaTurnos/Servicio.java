
package ProgramaTurnos;

/**
 *
 * @author camil
 */
public class Servicio {
    
    
    private String TipoServicio;

    public String getTipoServicio() {
        return TipoServicio;
    }

    public void setTipoServicio(String TipoServicio) {
        this.TipoServicio = TipoServicio;
    }

    public Servicio(String TipoServicio) {
        this.TipoServicio = TipoServicio;
    }
    
}
