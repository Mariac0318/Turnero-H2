
package ProgramaTurnos;
/**
 *
 * @author camil
 */
public class Turnero {
    
    
    private int NumeroTurno;
    private String Servicio;
    private String Prioridad;

    public int getNumeroTurno() {
        return NumeroTurno;
    }

    public void setNumeroTurno(int NumeroTurno) {
        this.NumeroTurno = NumeroTurno;
    }

    public String getServicio() {
        return Servicio;
    }

    public void setServicio(String Servicio) {
        this.Servicio = Servicio;
    }

    public String getPrioridad() {
        return Prioridad;
    }

    public void setPrioridad(String Prioridad) {
        this.Prioridad = Prioridad;
    }

    public Turnero(int NumeroTurno, String Servicio, String Prioridad) {
        this.NumeroTurno = NumeroTurno;
        this.Servicio = Servicio;
        this.Prioridad = Prioridad;
    }
    
    
}
