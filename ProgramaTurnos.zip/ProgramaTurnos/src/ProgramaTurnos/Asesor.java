
package ProgramaTurnos;

import javax.persistence.Entity;
import javax.persistence.Table;

/**
 *
 * @author camil
 */

@Entity
@Table (name = "Asesor")
public class Asesor extends Persona {
    
    private String Nombre;
    private String Apellido;
    private String Estado;
    private String TipoServicio;

    public Asesor() {
    }

    public Asesor(String Nombre, String Apellido, int Telefono) {
        super(Nombre, Apellido, Telefono);
    }

    public String getNombre() {
        return Nombre;
    }

    public void setNombre(String Nombre) {
        this.Nombre = Nombre;
    }

    public String getApellido() {
        return Apellido;
    }

    public void setApellido(String Apellido) {
        this.Apellido = Apellido;
    }

    public String getEstado() {
        return Estado;
    }

    public void setEstado(String Estado) {
        this.Estado = Estado;
    }

    public String getTipoServicio() {
        return TipoServicio;
    }

    public void setTipoServicio(String TipoServicio) {
        this.TipoServicio = TipoServicio;
    }

    
    
    
    
}
